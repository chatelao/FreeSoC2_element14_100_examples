/*******************************************************************************
* File Name: CapSense_CSD_PM.c
* Version 1.0
*
* Description:
*  This file provides Sleep APIs for CapSense CSD Component.
*
* Note:
*
********************************************************************************
* Copyright 2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CapSense_CSD.h"

CapSense_CSD_BACKUP_STRUCT CapSense_CSD_backup =
{   
    0x00u, /* enableState; */
};


/*******************************************************************************
* Function Name: CapSense_CSD_SaveConfig
********************************************************************************
*
* Summary:
*  Saves customer configuration of CapSense none-retention registers. Resets 
*  all sensors to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSense_CSD_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
* Reentrant:
*  No - for PSoC5 ES1 silicon, Yes - for PSoC3 ES3.
*
*******************************************************************************/
void CapSense_CSD_SaveConfig(void)
{    

    /* Clear all sensors */
    CapSense_CSD_ClearSensors();
    
    /* The pins disable is customer concern: Cmod and Rb */
}


/*******************************************************************************
* Function Name: CapSense_CSD_Sleep
********************************************************************************
*
* Summary:
*  Disables Active mode power template bits for number of component used within 
*  CapSense. Calls CapSense_CSD_SaveConfig() function to save customer 
*  configuration of CapSense none-retention registers and resets all sensors 
*  to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSense_CSD_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
* Reentrant:
*  No
*
*******************************************************************************/
void CapSense_CSD_Sleep(void)
{
 
    CapSense_CSD_SaveConfig();
}


/*******************************************************************************
* Function Name: CapSense_CSD_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores CapSense configuration and non-retention register values.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Must be called only after CapSense_CSD_SaveConfig() routine. Otherwise 
*  the component configuration will be overwritten with its initial setting.  
*
* Global Variables:
*  CapSense_CSD_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
*******************************************************************************/
void CapSense_CSD_RestoreConfig(void)
{   

}
 

/*******************************************************************************
* Function Name: CapSense_CSD_Wakeup
********************************************************************************
*
* Summary:
*  Restores CapSense configuration and non-retention register values. 
*  Restores enabled state of component by setting Active mode power template 
*  bits for number of component used within CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CapSense_CSD_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
*******************************************************************************/
void CapSense_CSD_Wakeup(void)
{
    CapSense_CSD_RestoreConfig();
    
    /* Restore CapSense Enable state */
    if (CapSense_CSD_backup.enableState != 0u)
    {
        CapSense_CSD_Enable();
    }
}


/* [] END OF FILE */
