/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#if !defined(CY_CAPSENSE_CSD_SMS_CapSense_CSD_H)
#define CY_CAPSENSE_CSD_SMS_CapSense_CSD_H

#include "CapSense_CSD.h"

typedef struct
{
    uint8 totalScanslotsNum;
    uint8 *idac1LevelsTbl;
    uint8 *idac2LevelsTbl;
    const uint8 *sensetivityTbl;
    uint8 *chargeDivTbl;
    uint8 *modDivTbl;
    uint8  *widgetNubmersTbl;
    uint32 *resolutionsTbl;
    uint16 IMOFreq_kHz;
    uint16 (*ptrGetRaw)(uint8 sensor, uint8 avgSamples);
}CapSense_CSD_ConfigType;

void CapSense_CSD_AutoTune(void);
void CapSense_CSD_CalculateThresholds(uint8 sensor);

void CapSense_CSD_DisableBaselineIDAC(void);
void CapSense_CSD_EnableBaselineIDAC(CapSense_CSD_ConfigType *config);

uint16  CapSense_CSD_GetSensorRaw(uint8 sensor, uint8 avgSamples);

void TunePrescalers(CapSense_CSD_ConfigType *config);
void TuneSensitivity(CapSense_CSD_ConfigType *config);
void CalculateThresholds(const uint8 bSensorNumber, const uint16 *rawData, const uint8 *widgetNumber, uint8 *bFingerThres, uint8 *bNoiseThres);
void CalibrateSensors(CapSense_CSD_ConfigType *config, uint16 rawLevel);

#endif  /* (CY_CAPSENSE_CSD_SMS_CapSense_CSD_H) */

//[] END OF FILE
