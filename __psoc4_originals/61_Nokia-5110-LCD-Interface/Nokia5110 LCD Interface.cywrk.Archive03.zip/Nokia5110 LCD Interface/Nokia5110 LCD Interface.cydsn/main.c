/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/*******************************************************************************
* This project displays Cypress Logo (bitmap image) and some strings
* It uses bit-banging method (sending the data bit-by-bit from CPU)
********************************************************************************/

#include <device.h>
#include "Nokia5110LCD.h"

void main()
{
    /* Initialize the LCD */
    LCD_Init();
    
    /* Go to Row 0 & Column 0 */
    LCD_gotoXY(0,0);
    
    /* Print a string */
    LCD_String("PSoC Rocks !");
    
    /* Go to Row 2 & Column 0 */
    LCD_gotoXY(0,2);
    
    /* Print a string */
    LCD_String("Element 14");
    
    /* Go to Row 4 & Column 0 */
    LCD_gotoXY(0,4);
    
    /* Print a string */
    LCD_String("Example Proj");
        
    for(;;)
    {

    }
}

/* [] END OF FILE */
