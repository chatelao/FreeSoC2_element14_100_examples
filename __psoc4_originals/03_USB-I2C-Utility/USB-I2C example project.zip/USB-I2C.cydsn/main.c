/******************************************************************************
* Project Name		: USB-I2C
* File Name			: main.c
* Version 			: 1.0
* Device Used		: CY8C4245AXI-483
* Software Used		: PSoC Creator 2.2 SP1
* Compiler    		: ARMGCC 4.4.1
* Related Hardware	: CY8CKIT-042 PSoC 4 Pioneer Kit 
******************************************************************************
* ========================================
*
The following firmware was developed by Cypress Semiconductor
This work is licensed under a Creative Commons Attribution 3.0 Unported License.
http://creativecommons.org/licenses/by/3.0/deed.en_US
You are free to:
-To Share — to copy, distribute and transmit the work 
-To Remix — to adapt the work 
-To make commercial use of the work
* ========================================
*
*                           THEORY OF OPERATION
* This project demonstrates I2C communication over the kit USB-I2C Bridge. 
* The project uses the SCB based I2C component which receives and transfers the data  
* from the USB-I2C software (Bridge Control Panel).
*
* I2C is configured with 
* Mode: Slave
* Data rate (kbps): 400
* Slve address (7-bit): 0x08
* ******************************************************************************/ 

#include <device.h>

void main()
{

	uint8 wrBuf[10];  /* I2C write buffer */
	uint8 rdBuf[10];  /* I2C read buffer */
	uint8 indexCntr;
	uint32 byteCnt;
	
	/* Enable the Global Interrupt */
	CyGlobalIntEnable;
	
	/* Start I2C Slave operation */
	I2C_Start();
	
	/* Initialize write buffer */
	I2C_I2CSlaveInitWriteBuf((uint8 *) wrBuf, 10);
	
	/* Initialize read buffer */
	I2C_I2CSlaveInitReadBuf((uint8 *) rdBuf, 10);
	
	for(;;) /* Loop forever */
	{
	
		/* Wait for I2C master to complete a write */
		if(0u != (I2C_I2CSlaveStatus() & I2C_I2C_SSTAT_WR_CMPLT))
		{
			
			/* Read the number of bytes transferred */
			byteCnt = I2C_I2CSlaveGetWriteBufSize();
			
			/* Clear the write status bits*/
			I2C_I2CSlaveClearWriteStatus();
			
			/* Move the data written by the master to the read buffer so that the master can read back the data */
			for(indexCntr = 0; indexCntr < byteCnt; indexCntr++)
			{
				rdBuf [indexCntr] = wrBuf[indexCntr]; /* Loop back the data to the read buffer */
			}
			
			/* Clear the write buffer pointer so that the next write operation will start from index 0 */
			I2C_I2CSlaveClearWriteBuf();
			
			/* Clear the read buffer pointer so that the next read operations starts from index 0 */
			I2C_I2CSlaveClearReadBuf();
		}
		/* If the master has read the data , reset the read buffer pointer to 0 and clear the read status */
		if(0u != (I2C_I2CSlaveStatus() & I2C_I2C_SSTAT_RD_CMPLT))
		{
			/* Clear the read buffer pointer so that the next read operations starts from index 0 */
			I2C_I2CSlaveClearReadBuf();
			
			/* Clear the read status bits */
			I2C_I2CSlaveClearReadStatus();
		}
	}
	
}